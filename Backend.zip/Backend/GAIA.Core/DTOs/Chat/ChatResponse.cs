namespace GAIA.Core.DTOs.Chat
{
    public class ChatResponse
    {
        public string? ReasoningSummary { get; set; }
        public string Response { get; set; }
    }
}
