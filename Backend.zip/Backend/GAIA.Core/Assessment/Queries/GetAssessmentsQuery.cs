using MediatR;

namespace GAIA.Core.Assessment.Queries
{
  public record GetAssessmentsQuery() : IRequest<IReadOnlyList<AssessmentDetails>>;
}
