using GAIA.Domain.Assessment.DomainEvents;
using GAIA.Domain.Assessment.Entities;
using Marten.Events.Aggregation;

namespace GAIA.Infra.Projections
{
  public class AssessmentProjection : SingleStreamProjection<Assessment, Guid>
  {
    public void Apply(AssessmentCreated e, Assessment assessment)
    {
      assessment.Id = e.Id;
      assessment.Title = e.Title;
      assessment.Description = e.Description;
      assessment.CreatedAt = e.CreatedAt;
      assessment.CreatedBy = e.CreatedBy;
      assessment.FrameworkId = e.FrameworkId;
      assessment.AssessmentDepthId = e.AssessmentDepthId;
      assessment.AssessmentScoringId = e.AssessmentScoringId;
    }

    public void Apply(AssessmentEvidenceDocumentAdded e, Assessment assessment)
    {
      assessment.Apply(e);
    }
  }
}
