﻿using System;

namespace PIF.EBP.Application.Lookups.DTOs
{
    public class MasterData
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string NameAr { get; set; }
    }
}
