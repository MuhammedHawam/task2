﻿using System.Collections.Generic;

namespace PIF.EBP.Application.Lookups.DTOs
{
    public class LookupDataRequestDto
    {
        public List<string> keys { get; set; }
    }
}
