﻿using PIF.EBP.Core.DependencyInjection;

namespace PIF.EBP.Application.EntitiesCache
{
    public interface IEntitiesCrmQueries : ICrmQueriesBase, ITransientDependency
    {
       
    }
}
