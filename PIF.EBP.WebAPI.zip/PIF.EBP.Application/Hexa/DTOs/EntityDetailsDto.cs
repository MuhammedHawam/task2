﻿namespace PIF.EBP.Application.Hexa.DTOs
{
    public class EntityDetailsDto
    {
        public string DisplayName { get; set; }
        public string LogicalName { get; set; }
        public string Description { get; set; }
    }
}
