﻿using PIF.EBP.Core.DependencyInjection;

namespace PIF.EBP.Application.MetaData
{
    public interface IMetadataCrmQueries : ICrmQueriesBase, ITransientDependency
    {
        
    }
}
