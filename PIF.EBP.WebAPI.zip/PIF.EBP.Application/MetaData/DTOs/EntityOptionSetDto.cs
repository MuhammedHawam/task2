﻿namespace PIF.EBP.Application.MetaData.DTOs
{
    public class EntityOptionSetDto
    {
        public string Value { get; set; }
        public string Name { get; set; }
        public string NameAr { get; set; }
    }
    public class EntityOptionSetOptions
    {
        public string EntityName { get; set; }
        public string AttributeName { get; set; }
    }
}
