﻿namespace PIF.EBP.Application.MetaData.DTOs
{
    public class DeleteEntityRecordRequest
    {
        public string EntityName { get; set; }
        public string Id { get; set; }
    }
}
