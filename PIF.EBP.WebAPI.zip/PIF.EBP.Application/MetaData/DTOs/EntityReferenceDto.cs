﻿namespace PIF.EBP.Application.MetaData.DTOs
{
    public class EntityReferenceDto
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string NameAr { get; set; }
    }
}
