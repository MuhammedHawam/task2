﻿namespace PIF.EBP.Application.Shared
{
    public static class Consts
    {
        public const string ResetPasswordWorkflowId = "8439A9FE-0A66-4B57-82C5-D36CF24961B6";
    }
}
