﻿namespace PIF.EBP.Application.Commercialization.DTOs
{
    public class SurveyStatusDto
    {
        public string State { get; set; }
    }
}
