﻿namespace PIF.EBP.Application.Commercialization.DTOs
{
    public class ProfileDataRequest
    {
        public string ObjectId { get; set; }
        public string ObjectType { get; set; }
    }
}
