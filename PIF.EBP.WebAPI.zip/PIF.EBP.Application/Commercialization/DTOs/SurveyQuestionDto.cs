﻿namespace PIF.EBP.Application.Commercialization.DTOs
{
    public class SurveyQuestionDto
    {
        public string Question { get; set; }
        public string Order { get; set; }
        public string Mandatory { get; set; }
        public string Datatype { get; set; }
        public string Min { get; set; }
        public string Max { get; set; }
    }
}
