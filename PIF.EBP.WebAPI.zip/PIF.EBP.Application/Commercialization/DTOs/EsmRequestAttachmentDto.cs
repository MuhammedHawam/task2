﻿namespace PIF.EBP.Application.Commercialization.DTOs
{
    public class EsmRequestAttachmentDto
    {
        public string FileName { get; set; }

        public string ContentType { get; set; }

        public string SysId { get; set; }
    }
}
