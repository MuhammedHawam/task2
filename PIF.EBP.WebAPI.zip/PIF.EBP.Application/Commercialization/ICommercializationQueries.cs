﻿using PIF.EBP.Core.DependencyInjection;

namespace PIF.EBP.Application.Commercialization
{
    public interface ICommercializationQueries : ICrmQueriesBase, ITransientDependency
    {

    }
}
