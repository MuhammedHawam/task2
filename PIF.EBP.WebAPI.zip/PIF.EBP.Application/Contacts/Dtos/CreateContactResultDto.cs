﻿namespace PIF.EBP.Application.Contacts.Dtos
{
    public class CreateContactResultDto
    {
        public string Message { get; set; }
        public bool RequireAdminApproval { get; set; }
    }
}
