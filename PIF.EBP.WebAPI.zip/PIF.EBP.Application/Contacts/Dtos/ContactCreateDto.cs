﻿namespace PIF.EBP.Application.Contacts.Dtos
{
    public class ContactCreateDto : ContactDtoBase
    {
    }
}
