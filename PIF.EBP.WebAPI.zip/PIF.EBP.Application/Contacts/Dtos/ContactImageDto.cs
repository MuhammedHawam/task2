﻿namespace PIF.EBP.Application.Contacts.Dtos
{
    public class ContactImageDto
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string NameAr { get; set; }
        public byte[] EntityImage { get; set; }
    }
}
