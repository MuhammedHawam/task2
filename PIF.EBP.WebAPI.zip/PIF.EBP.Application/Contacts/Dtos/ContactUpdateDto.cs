﻿namespace PIF.EBP.Application.Contacts.Dtos
{
    public class ContactUpdateDto : ContactDtoBase
    {
        public string Id { get; set; }
    }
}
