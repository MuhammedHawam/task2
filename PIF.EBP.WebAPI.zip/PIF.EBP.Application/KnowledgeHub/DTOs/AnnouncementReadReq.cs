﻿using System;

namespace PIF.EBP.Application.KnowledgeHub.DTOs
{
    public class AnnouncementReadReq
    {
        public Guid? Id { get; set; }
    }
}
