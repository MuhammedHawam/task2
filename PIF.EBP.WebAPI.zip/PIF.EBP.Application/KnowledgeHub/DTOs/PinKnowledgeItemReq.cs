﻿using System;

namespace PIF.EBP.Application.KnowledgeHub.DTOs
{
    public class PinKnowledgeItemReq
    {
        public Guid Id { get; set; }
        public bool IsPin { get; set; }
    }
}
