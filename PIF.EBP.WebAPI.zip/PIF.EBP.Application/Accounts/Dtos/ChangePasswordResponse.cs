﻿namespace PIF.EBP.Application.Accounts.Dtos
{
    public class ChangePasswordResponse
    {
        public bool IsSuccess { get; set; }
    }
}
