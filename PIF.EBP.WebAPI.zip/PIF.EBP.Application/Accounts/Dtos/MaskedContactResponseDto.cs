﻿namespace PIF.EBP.Application.InvitationFlow.Dtos
{
    public class MaskedContactResponseDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string MobilePhone { get; set; }
    }
}
