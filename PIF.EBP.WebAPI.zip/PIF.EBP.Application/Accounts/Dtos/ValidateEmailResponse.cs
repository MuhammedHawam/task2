﻿namespace PIF.EBP.Application.Accounts.Dtos
{
    public class ValidateEmailResponse
    {
        public string MaskedPhone { get; set; }
    }
}
