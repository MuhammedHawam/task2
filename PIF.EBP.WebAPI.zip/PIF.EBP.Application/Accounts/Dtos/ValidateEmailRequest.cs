﻿namespace PIF.EBP.Application.Accounts.Dtos
{
    public class ValidateEmailRequest
    {
        public string Email { get; set; }

    }
}
