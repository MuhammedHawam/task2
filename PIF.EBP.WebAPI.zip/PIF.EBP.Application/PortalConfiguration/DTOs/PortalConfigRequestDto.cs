﻿using System.Collections.Generic;

namespace PIF.EBP.Application.PortalConfiguration.DTOs
{
    public class PortalConfigRequestDto
    {
        public List<string> Keys { get; set; }
    }
}
