﻿namespace PIF.EBP.Application.PortalConfiguration.DTOs
{
    public class CreateOrUpdatePortalConfigDto
    {
        public string Key { get; set; }
        public string Value { get; set; }
        public string ValueAr { get; set; }
        public int Type { get; set; }
    }
}
