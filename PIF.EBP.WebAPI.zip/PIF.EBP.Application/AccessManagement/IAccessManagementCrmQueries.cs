﻿using PIF.EBP.Core.DependencyInjection;

namespace PIF.EBP.Application.AccessManagement
{
    public interface IAccessManagementCrmQueries : ICrmQueriesBase, ITransientDependency
    {
        
    }
}
