﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIF.EBP.Application.Synergy.DTOs
{
    public class SectorLookupDto
    {
        public Guid SectorId { get; set; }
        public string SectorName { get; set; }
    }
}
