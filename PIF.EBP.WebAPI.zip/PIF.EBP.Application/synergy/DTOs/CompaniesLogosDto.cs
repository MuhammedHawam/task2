﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIF.EBP.Application.Synergy.DTOs
{
    public class CompaniesLogosDto
    {
        public Guid CompanyId { get; set; }
        public string CompanyLogo { get; set; }
    }
}
