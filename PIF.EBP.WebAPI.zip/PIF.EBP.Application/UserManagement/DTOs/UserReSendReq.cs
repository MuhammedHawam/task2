﻿using System;

namespace PIF.EBP.Application.UserManagement.DTOs
{
    public class UserReSendReq
    {
        public Guid AssociationId { get; set; }
    }
}
