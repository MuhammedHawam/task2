﻿using System;

namespace PIF.EBP.Application.UserManagement.DTOs
{
    public class UserInviteReq
    {
        public Guid ContactId { get; set; }
    }
}
