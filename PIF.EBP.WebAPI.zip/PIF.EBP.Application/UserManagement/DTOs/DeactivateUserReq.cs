﻿using System;

namespace PIF.EBP.Application.UserManagement.DTOs
{
    public class DeactivateUserReq
    {
        public Guid AssociationId { get; set; }
    }
}
