﻿namespace PIF.EBP.Core.DependencyInjection
{
    public interface IScopedDependency { }

    public interface ITransientDependency { }

    public interface ISingletonDependency { }
}
