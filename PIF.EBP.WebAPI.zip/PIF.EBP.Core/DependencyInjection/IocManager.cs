﻿using Castle.Windsor;

namespace PIF.EBP.Core.DependencyInjection
{
    public class IocManager
    {
        public IWindsorContainer IocContainer { get; }
    }
}
