﻿namespace PIF.EBP.Core.Shared
{
    public static class ApplicationConsts
    {
        public const string ESMHttpClientName = "ESMHttpClient";
    }
}
