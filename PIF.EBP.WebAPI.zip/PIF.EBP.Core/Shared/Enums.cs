﻿namespace PIF.EBP.Core.Shared
{
    public class Enums
    {
        public enum FileOverriddenAction
        {
            NoAction = 0,
            KeepBoth = 1,
            Replace = 2
        }
    }
}
