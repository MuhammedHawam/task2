﻿namespace PIF.EBP.Core.Search.Entities
{
    public class CalendarEntity : EntityBase
    {
        public string Title { get; set; }
    }
}
