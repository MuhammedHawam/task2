﻿namespace PIF.EBP.Core.Search.Entities
{
    public class RequestEntity : EntityBase
    {
        public string Title { get; set; }
        public string Purpose { get; set; }
        public string SomethingElse { get; set; }
    }
}
