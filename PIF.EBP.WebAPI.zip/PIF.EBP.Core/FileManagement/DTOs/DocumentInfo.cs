﻿namespace PIF.EBP.Core.FileManagement.DTOs
{
    public class DocumentInfo
    {
        public string DocumentName { get; set; }
        public string DocumentPath { get; set; }
        public string FolderPath { get; set; }
        public string DocumentContent { get; set; }
        //company divsion (division) > realestate/mena/iid
        //secortor (MENA divisions)
        
    }
}
