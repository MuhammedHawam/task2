﻿namespace PIF.EBP.Core.FileManagement.DTOs
{
    public class DocumentMetadataDto
    {
        public string FieldName { get; set; }
        public string FieldType { get; set; }
        public string DisplayName { get; set; }
    }
}
