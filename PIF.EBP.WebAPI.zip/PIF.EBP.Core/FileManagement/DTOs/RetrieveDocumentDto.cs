﻿namespace PIF.EBP.Core.FileManagement.DTOs
{
    public class RetrieveDocumentDto
    {
        public string AttachmentPath { get; set; }

        public string User { get; set; }
    }
}
