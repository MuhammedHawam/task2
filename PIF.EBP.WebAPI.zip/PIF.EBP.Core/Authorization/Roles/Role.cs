﻿namespace PIF.EBP.Core.Authorization.Roles
{
    public class Role
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string DisplayName { get; set; }

    }
}
