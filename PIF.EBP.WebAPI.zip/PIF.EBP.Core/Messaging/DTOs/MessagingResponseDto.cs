﻿using System.Collections.Generic;

namespace PIF.EBP.Core.Messaging.DTOs
{
    public class MessagingResponseDto
    {
        public List<byte[]> Messages { get; set; }
    }
}
