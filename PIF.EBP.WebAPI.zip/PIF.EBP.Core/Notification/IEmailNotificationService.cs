﻿namespace PIF.EBP.Core.Notification
{
    public interface IEmailNotificationService : INotificationService
    {
    }
}
